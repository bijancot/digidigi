--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.10
-- Dumped by pg_dump version 11.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: panji
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO panji;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: backend_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backend_user (
    "USERNAME" character varying(30) NOT NULL,
    "NAME" character varying(50) NOT NULL,
    "PASSWORD" character varying(255) NOT NULL,
    "ROLE" character varying(10) NOT NULL,
    "DEFAULT_PASSWORD" boolean
);


ALTER TABLE public.backend_user OWNER TO postgres;

--
-- Name: banner; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banner (
    "ID_BANNER" integer NOT NULL,
    "ID_NEWS" integer NOT NULL,
    "IMAGE_BANNER" character varying(255) NOT NULL,
    "DATE_BANNER" timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.banner OWNER TO postgres;

--
-- Name: captcha_ID_CAPTCHA_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."captcha_ID_CAPTCHA_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public."captcha_ID_CAPTCHA_seq" OWNER TO postgres;

--
-- Name: captcha; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.captcha (
    "ID_CAPTCHA" integer DEFAULT nextval('public."captcha_ID_CAPTCHA_seq"'::regclass) NOT NULL,
    "CAPTCHA_TIME" bigint NOT NULL,
    "IP_ADDRESS" character varying(16) NOT NULL,
    "WORD" character varying(20) NOT NULL
);


ALTER TABLE public.captcha OWNER TO postgres;

--
-- Name: category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category (
    "ID_CATEGORY" character(1) NOT NULL,
    "NAME_CATEGORY" character varying(15)
);


ALTER TABLE public.category OWNER TO postgres;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comments (
    "ID_COMMENT" bigint NOT NULL,
    "ID_NEWS" integer NOT NULL,
    "EMAIL" character varying(50) NOT NULL,
    "COMMENT_TEXT" text NOT NULL,
    "IS_APPROVED" boolean NOT NULL,
    "DATE_APPROVED" timestamp(0) without time zone,
    "DATE_COMMENT" timestamp(0) without time zone NOT NULL,
    "ADMIN_REPLY" text
);


ALTER TABLE public.comments OWNER TO postgres;

--
-- Name: comments_ID_COMMENT_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."comments_ID_COMMENT_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."comments_ID_COMMENT_seq" OWNER TO postgres;

--
-- Name: comments_ID_COMMENT_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."comments_ID_COMMENT_seq" OWNED BY public.comments."ID_COMMENT";


--
-- Name: cover_story; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cover_story (
    "ID_COVERSTORY" bigint NOT NULL,
    "TITLE_COVERSTORY" character varying(100) NOT NULL,
    "SUMMARY" text NOT NULL,
    "IMAGE_COVERSTORY" character varying(255) NOT NULL,
    "DATE_COVERSTORY" timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.cover_story OWNER TO postgres;

--
-- Name: cover_story_ID_COVERSTORY_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."cover_story_ID_COVERSTORY_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."cover_story_ID_COVERSTORY_seq" OWNER TO postgres;

--
-- Name: cover_story_ID_COVERSTORY_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."cover_story_ID_COVERSTORY_seq" OWNED BY public.cover_story."ID_COVERSTORY";


--
-- Name: emagz_ID_EMAGZ_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."emagz_ID_EMAGZ_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."emagz_ID_EMAGZ_seq" OWNER TO postgres;

--
-- Name: emagz; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.emagz (
    "ID_EMAGZ" integer DEFAULT nextval('public."emagz_ID_EMAGZ_seq"'::regclass) NOT NULL,
    "THUMBNAIL" character varying(255),
    "FILE" character varying(255),
    "DATE_UPLOADED" timestamp(0) without time zone NOT NULL,
    "NAME" character varying(100) NOT NULL
);


ALTER TABLE public.emagz OWNER TO postgres;

--
-- Name: firebase_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.firebase_token (
    "TOKEN" character varying(255) NOT NULL
);


ALTER TABLE public.firebase_token OWNER TO postgres;

--
-- Name: galeri; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.galeri (
    "IMAGE_FILE" character varying(255) NOT NULL,
    "ID_NEWS" bigint
);


ALTER TABLE public.galeri OWNER TO postgres;

--
-- Name: likes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.likes (
    "ID_LIKES" bigint NOT NULL,
    "EMAIL" character varying(50) NOT NULL,
    "ID_NEWS" integer NOT NULL
);


ALTER TABLE public.likes OWNER TO postgres;

--
-- Name: likes_ID_LIKES_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."likes_ID_LIKES_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."likes_ID_LIKES_seq" OWNER TO postgres;

--
-- Name: likes_ID_LIKES_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."likes_ID_LIKES_seq" OWNED BY public.likes."ID_LIKES";


--
-- Name: news; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.news (
    "ID_NEWS" integer NOT NULL,
    "ID_CATEGORY" character(1) NOT NULL,
    "TITLE_NEWS" character varying(200) NOT NULL,
    "CONTENT_NEWS" text,
    "VIEWS_COUNT" bigint NOT NULL,
    "SHARES_COUNT" bigint NOT NULL,
    "DATE_NEWS" timestamp(0) without time zone NOT NULL,
    "NEWS_IMAGE" character varying(255),
    "USER_EDITOR" character varying(30) DEFAULT ''::character varying,
    "USER_VERIFICATOR" character varying(30),
    "STATUS" character varying(10),
    "URL" character varying(255)
);


ALTER TABLE public.news OWNER TO postgres;

--
-- Name: news_ID_NEWS_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."news_ID_NEWS_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."news_ID_NEWS_seq" OWNER TO postgres;

--
-- Name: news_ID_NEWS_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."news_ID_NEWS_seq" OWNED BY public.news."ID_NEWS";


--
-- Name: news_cover; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.news_cover (
    "ID_COVERSTORY" bigint NOT NULL,
    "ID_NEWS" bigint NOT NULL
);


ALTER TABLE public.news_cover OWNER TO postgres;

--
-- Name: news_share; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.news_share (
    "ID" integer NOT NULL,
    "EMAIL" character varying(50) NOT NULL,
    "ID_NEWS" integer NOT NULL
);


ALTER TABLE public.news_share OWNER TO postgres;

--
-- Name: news_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.news_tags (
    "ID_TAGS" integer NOT NULL,
    "ID_NEWS" integer NOT NULL
);


ALTER TABLE public.news_tags OWNER TO postgres;

--
-- Name: news_view; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.news_view (
    "ID" integer NOT NULL,
    "EMAIL" character varying(50) NOT NULL,
    "ID_NEWS" integer NOT NULL
);


ALTER TABLE public.news_view OWNER TO postgres;

--
-- Name: tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tags (
    "ID_TAGS" integer NOT NULL,
    "TAGS" character varying(50) NOT NULL,
    "DATE_CREATED" timestamp(0) without time zone
);


ALTER TABLE public.tags OWNER TO postgres;

--
-- Name: tag_ID_TAG_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."tag_ID_TAG_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."tag_ID_TAG_seq" OWNER TO postgres;

--
-- Name: tag_ID_TAG_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."tag_ID_TAG_seq" OWNED BY public.tags."ID_TAGS";


--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    "EMAIL" character varying(50) NOT NULL,
    "USER_NAME" character varying(100) NOT NULL,
    "PROFILEPIC_URL" text,
    "LAST_LOGIN" timestamp(0) without time zone NOT NULL,
    "DATE_BIRTH" date,
    "GENDER" character(1),
    "USER_TYPE" character varying(10)
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: video; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.video (
    "ID_VIDEO" character varying(15) NOT NULL,
    "TITLE" character varying(100),
    "DESCRIPTION" text,
    "DATE_PUBLISHED" timestamp(0) without time zone,
    "URL_DEFAULT_THUMBNAIL" character varying(255),
    "URL_MEDIUM_THUMBNAIL" character varying(255),
    "URL_HIGH_THUMBNAIL" character varying(255),
    "STATUS_PUBLISHED" boolean DEFAULT true NOT NULL
);


ALTER TABLE public.video OWNER TO postgres;

--
-- Name: view_comments; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_comments AS
SELECT
    NULL::integer AS "ID_NEWS",
    NULL::character(1) AS "ID_CATEGORY",
    NULL::character varying(200) AS "TITLE_NEWS",
    NULL::bigint AS "COMMENTS";


ALTER TABLE public.view_comments OWNER TO postgres;

--
-- Name: view_likes; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_likes AS
SELECT
    NULL::integer AS "ID_NEWS",
    NULL::character(1) AS "ID_CATEGORY",
    NULL::character varying(200) AS "TITLE_NEWS",
    NULL::bigint AS "LIKES";


ALTER TABLE public.view_likes OWNER TO postgres;

--
-- Name: view_news; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_news AS
 SELECT news."ID_NEWS",
    category."NAME_CATEGORY",
    news."TITLE_NEWS",
    news."CONTENT_NEWS",
    news."VIEWS_COUNT",
    news."SHARES_COUNT",
    news."DATE_NEWS",
    news."NEWS_IMAGE",
    view_likes."LIKES",
    COALESCE(view_comments."COMMENTS", (0)::bigint, view_comments."COMMENTS") AS "COMMENTS",
    "E"."NAME" AS "EDITOR",
    "V"."NAME" AS "VERIFICATOR",
    news."STATUS"
   FROM (((((public.news
     JOIN public.category ON ((news."ID_CATEGORY" = category."ID_CATEGORY")))
     LEFT JOIN public.view_likes ON ((view_likes."ID_NEWS" = news."ID_NEWS")))
     LEFT JOIN public.view_comments ON ((view_comments."ID_NEWS" = news."ID_NEWS")))
     LEFT JOIN public.backend_user "E" ON (((news."USER_EDITOR")::text = ("E"."USERNAME")::text)))
     LEFT JOIN public.backend_user "V" ON (((news."USER_VERIFICATOR")::text = ("V"."USERNAME")::text)));


ALTER TABLE public.view_news OWNER TO postgres;

--
-- Name: view_news_comments; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_news_comments AS
 SELECT comments."ID_COMMENT",
    comments."ID_NEWS",
    comments."EMAIL",
    comments."COMMENT_TEXT",
    comments."IS_APPROVED",
    comments."DATE_COMMENT",
    "user"."USER_NAME",
    "user"."PROFILEPIC_URL",
    comments."ADMIN_REPLY"
   FROM ((public.news
     JOIN public.comments ON ((comments."ID_NEWS" = news."ID_NEWS")))
     JOIN public."user" ON (((comments."EMAIL")::text = ("user"."EMAIL")::text)));


ALTER TABLE public.view_news_comments OWNER TO postgres;

--
-- Name: view_news_cover; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_news_cover AS
 SELECT view_news."ID_NEWS",
    view_news."NAME_CATEGORY",
    view_news."TITLE_NEWS",
    view_news."CONTENT_NEWS",
    cover_story."ID_COVERSTORY",
    cover_story."TITLE_COVERSTORY",
    view_news."VIEWS_COUNT",
    view_news."SHARES_COUNT",
    view_news."DATE_NEWS",
    view_news."NEWS_IMAGE",
    view_news."LIKES",
    view_news."COMMENTS",
    view_news."EDITOR",
    view_news."VERIFICATOR",
    view_news."STATUS"
   FROM ((public.view_news
     LEFT JOIN public.news_cover ON ((news_cover."ID_NEWS" = view_news."ID_NEWS")))
     LEFT JOIN public.cover_story ON ((news_cover."ID_COVERSTORY" = cover_story."ID_COVERSTORY")));


ALTER TABLE public.view_news_cover OWNER TO postgres;

--
-- Name: view_news_trending; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_news_trending AS
 SELECT news."ID_NEWS",
    news."ID_CATEGORY",
    news."TITLE_NEWS",
    news."DATE_NEWS",
    news."VIEWS_COUNT",
    COALESCE(view_comments."COMMENTS", (0)::bigint, view_comments."COMMENTS") AS "COMMENTS",
    COALESCE((news."VIEWS_COUNT" + view_comments."COMMENTS"), (0)::bigint, (news."VIEWS_COUNT" + view_comments."COMMENTS")) AS "TRENDING",
    news."STATUS"
   FROM (public.news
     LEFT JOIN public.view_comments ON ((view_comments."ID_NEWS" = news."ID_NEWS")))
  ORDER BY COALESCE((news."VIEWS_COUNT" + view_comments."COMMENTS"), (0)::bigint, (news."VIEWS_COUNT" + view_comments."COMMENTS")) DESC;


ALTER TABLE public.view_news_trending OWNER TO postgres;

--
-- Name: comments ID_COMMENT; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments ALTER COLUMN "ID_COMMENT" SET DEFAULT nextval('public."comments_ID_COMMENT_seq"'::regclass);


--
-- Name: cover_story ID_COVERSTORY; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cover_story ALTER COLUMN "ID_COVERSTORY" SET DEFAULT nextval('public."cover_story_ID_COVERSTORY_seq"'::regclass);


--
-- Name: likes ID_LIKES; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.likes ALTER COLUMN "ID_LIKES" SET DEFAULT nextval('public."likes_ID_LIKES_seq"'::regclass);


--
-- Name: news ID_NEWS; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news ALTER COLUMN "ID_NEWS" SET DEFAULT nextval('public."news_ID_NEWS_seq"'::regclass);


--
-- Name: tags ID_TAGS; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags ALTER COLUMN "ID_TAGS" SET DEFAULT nextval('public."tag_ID_TAG_seq"'::regclass);


--
-- Data for Name: backend_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backend_user ("USERNAME", "NAME", "PASSWORD", "ROLE", "DEFAULT_PASSWORD") FROM stdin;
\.
COPY public.backend_user ("USERNAME", "NAME", "PASSWORD", "ROLE", "DEFAULT_PASSWORD") FROM '$$PATH$$/3845.dat';

--
-- Data for Name: banner; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banner ("ID_BANNER", "ID_NEWS", "IMAGE_BANNER", "DATE_BANNER") FROM stdin;
\.
COPY public.banner ("ID_BANNER", "ID_NEWS", "IMAGE_BANNER", "DATE_BANNER") FROM '$$PATH$$/3846.dat';

--
-- Data for Name: captcha; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.captcha ("ID_CAPTCHA", "CAPTCHA_TIME", "IP_ADDRESS", "WORD") FROM stdin;
\.
COPY public.captcha ("ID_CAPTCHA", "CAPTCHA_TIME", "IP_ADDRESS", "WORD") FROM '$$PATH$$/3848.dat';

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category ("ID_CATEGORY", "NAME_CATEGORY") FROM stdin;
\.
COPY public.category ("ID_CATEGORY", "NAME_CATEGORY") FROM '$$PATH$$/3849.dat';

--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comments ("ID_COMMENT", "ID_NEWS", "EMAIL", "COMMENT_TEXT", "IS_APPROVED", "DATE_APPROVED", "DATE_COMMENT", "ADMIN_REPLY") FROM stdin;
\.
COPY public.comments ("ID_COMMENT", "ID_NEWS", "EMAIL", "COMMENT_TEXT", "IS_APPROVED", "DATE_APPROVED", "DATE_COMMENT", "ADMIN_REPLY") FROM '$$PATH$$/3850.dat';

--
-- Data for Name: cover_story; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cover_story ("ID_COVERSTORY", "TITLE_COVERSTORY", "SUMMARY", "IMAGE_COVERSTORY", "DATE_COVERSTORY") FROM stdin;
\.
COPY public.cover_story ("ID_COVERSTORY", "TITLE_COVERSTORY", "SUMMARY", "IMAGE_COVERSTORY", "DATE_COVERSTORY") FROM '$$PATH$$/3852.dat';

--
-- Data for Name: emagz; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.emagz ("ID_EMAGZ", "THUMBNAIL", "FILE", "DATE_UPLOADED", "NAME") FROM stdin;
\.
COPY public.emagz ("ID_EMAGZ", "THUMBNAIL", "FILE", "DATE_UPLOADED", "NAME") FROM '$$PATH$$/3855.dat';

--
-- Data for Name: firebase_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.firebase_token ("TOKEN") FROM stdin;
\.
COPY public.firebase_token ("TOKEN") FROM '$$PATH$$/3856.dat';

--
-- Data for Name: galeri; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.galeri ("IMAGE_FILE", "ID_NEWS") FROM stdin;
\.
COPY public.galeri ("IMAGE_FILE", "ID_NEWS") FROM '$$PATH$$/3857.dat';

--
-- Data for Name: likes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.likes ("ID_LIKES", "EMAIL", "ID_NEWS") FROM stdin;
\.
COPY public.likes ("ID_LIKES", "EMAIL", "ID_NEWS") FROM '$$PATH$$/3858.dat';

--
-- Data for Name: news; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.news ("ID_NEWS", "ID_CATEGORY", "TITLE_NEWS", "CONTENT_NEWS", "VIEWS_COUNT", "SHARES_COUNT", "DATE_NEWS", "NEWS_IMAGE", "USER_EDITOR", "USER_VERIFICATOR", "STATUS", "URL") FROM stdin;
\.
COPY public.news ("ID_NEWS", "ID_CATEGORY", "TITLE_NEWS", "CONTENT_NEWS", "VIEWS_COUNT", "SHARES_COUNT", "DATE_NEWS", "NEWS_IMAGE", "USER_EDITOR", "USER_VERIFICATOR", "STATUS", "URL") FROM '$$PATH$$/3860.dat';

--
-- Data for Name: news_cover; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.news_cover ("ID_COVERSTORY", "ID_NEWS") FROM stdin;
\.
COPY public.news_cover ("ID_COVERSTORY", "ID_NEWS") FROM '$$PATH$$/3862.dat';

--
-- Data for Name: news_share; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.news_share ("ID", "EMAIL", "ID_NEWS") FROM stdin;
\.
COPY public.news_share ("ID", "EMAIL", "ID_NEWS") FROM '$$PATH$$/3863.dat';

--
-- Data for Name: news_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.news_tags ("ID_TAGS", "ID_NEWS") FROM stdin;
\.
COPY public.news_tags ("ID_TAGS", "ID_NEWS") FROM '$$PATH$$/3864.dat';

--
-- Data for Name: news_view; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.news_view ("ID", "EMAIL", "ID_NEWS") FROM stdin;
\.
COPY public.news_view ("ID", "EMAIL", "ID_NEWS") FROM '$$PATH$$/3865.dat';

--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tags ("ID_TAGS", "TAGS", "DATE_CREATED") FROM stdin;
\.
COPY public.tags ("ID_TAGS", "TAGS", "DATE_CREATED") FROM '$$PATH$$/3866.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" ("EMAIL", "USER_NAME", "PROFILEPIC_URL", "LAST_LOGIN", "DATE_BIRTH", "GENDER", "USER_TYPE") FROM stdin;
\.
COPY public."user" ("EMAIL", "USER_NAME", "PROFILEPIC_URL", "LAST_LOGIN", "DATE_BIRTH", "GENDER", "USER_TYPE") FROM '$$PATH$$/3868.dat';

--
-- Data for Name: video; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.video ("ID_VIDEO", "TITLE", "DESCRIPTION", "DATE_PUBLISHED", "URL_DEFAULT_THUMBNAIL", "URL_MEDIUM_THUMBNAIL", "URL_HIGH_THUMBNAIL", "STATUS_PUBLISHED") FROM stdin;
\.
COPY public.video ("ID_VIDEO", "TITLE", "DESCRIPTION", "DATE_PUBLISHED", "URL_DEFAULT_THUMBNAIL", "URL_MEDIUM_THUMBNAIL", "URL_HIGH_THUMBNAIL", "STATUS_PUBLISHED") FROM '$$PATH$$/3869.dat';

--
-- Name: captcha_ID_CAPTCHA_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."captcha_ID_CAPTCHA_seq"', 159, true);


--
-- Name: comments_ID_COMMENT_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."comments_ID_COMMENT_seq"', 38, true);


--
-- Name: cover_story_ID_COVERSTORY_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."cover_story_ID_COVERSTORY_seq"', 5, true);


--
-- Name: emagz_ID_EMAGZ_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."emagz_ID_EMAGZ_seq"', 9, true);


--
-- Name: likes_ID_LIKES_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."likes_ID_LIKES_seq"', 114, true);


--
-- Name: news_ID_NEWS_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."news_ID_NEWS_seq"', 3, true);


--
-- Name: tag_ID_TAG_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."tag_ID_TAG_seq"', 6, true);


--
-- Name: backend_user backend_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backend_user
    ADD CONSTRAINT backend_user_pkey PRIMARY KEY ("USERNAME");


--
-- Name: banner banner_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banner
    ADD CONSTRAINT banner_pkey PRIMARY KEY ("ID_BANNER");


--
-- Name: captcha captcha_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.captcha
    ADD CONSTRAINT captcha_pkey PRIMARY KEY ("ID_CAPTCHA");


--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY ("ID_CATEGORY");


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY ("ID_COMMENT");


--
-- Name: cover_story cover_story_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cover_story
    ADD CONSTRAINT cover_story_pkey PRIMARY KEY ("ID_COVERSTORY");


--
-- Name: emagz emagz_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emagz
    ADD CONSTRAINT emagz_pkey PRIMARY KEY ("ID_EMAGZ");


--
-- Name: firebase_token firebase_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.firebase_token
    ADD CONSTRAINT firebase_token_pkey PRIMARY KEY ("TOKEN");


--
-- Name: galeri galeri_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.galeri
    ADD CONSTRAINT galeri_pkey PRIMARY KEY ("IMAGE_FILE");


--
-- Name: likes likes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_pkey PRIMARY KEY ("ID_LIKES");


--
-- Name: news news_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT news_pkey PRIMARY KEY ("ID_NEWS");


--
-- Name: news_share news_view_copy1_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news_share
    ADD CONSTRAINT news_view_copy1_pkey PRIMARY KEY ("ID");


--
-- Name: news_view news_view_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news_view
    ADD CONSTRAINT news_view_pkey PRIMARY KEY ("ID");


--
-- Name: tags tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tag_pkey PRIMARY KEY ("ID_TAGS");


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY ("EMAIL");


--
-- Name: video video_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.video
    ADD CONSTRAINT video_pkey PRIMARY KEY ("ID_VIDEO");


--
-- Name: view_comments _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.view_comments AS
 SELECT news."ID_NEWS",
    news."ID_CATEGORY",
    news."TITLE_NEWS",
    count(comments."ID_COMMENT") AS "COMMENTS"
   FROM (public.news
     LEFT JOIN public.comments ON ((comments."ID_NEWS" = news."ID_NEWS")))
  WHERE (comments."IS_APPROVED" = true)
  GROUP BY news."ID_NEWS", news."ID_CATEGORY";


--
-- Name: view_likes _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.view_likes AS
 SELECT news."ID_NEWS",
    news."ID_CATEGORY",
    news."TITLE_NEWS",
    count(likes."ID_LIKES") AS "LIKES"
   FROM (public.news
     LEFT JOIN public.likes ON ((likes."ID_NEWS" = news."ID_NEWS")))
  GROUP BY news."ID_NEWS", news."ID_CATEGORY";


--
-- Name: banner FK_banner; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banner
    ADD CONSTRAINT "FK_banner" FOREIGN KEY ("ID_NEWS") REFERENCES public.news("ID_NEWS") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: news_tags FK_detail_news_tags_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news_tags
    ADD CONSTRAINT "FK_detail_news_tags_1" FOREIGN KEY ("ID_TAGS") REFERENCES public.tags("ID_TAGS") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: news_tags FK_detail_news_tags_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news_tags
    ADD CONSTRAINT "FK_detail_news_tags_2" FOREIGN KEY ("ID_NEWS") REFERENCES public.news("ID_NEWS") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: galeri FK_galeri; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.galeri
    ADD CONSTRAINT "FK_galeri" FOREIGN KEY ("ID_NEWS") REFERENCES public.news("ID_NEWS") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: news FK_news_category; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT "FK_news_category" FOREIGN KEY ("ID_CATEGORY") REFERENCES public.category("ID_CATEGORY") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comments FK_news_comment; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT "FK_news_comment" FOREIGN KEY ("ID_NEWS") REFERENCES public.news("ID_NEWS") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: news_cover FK_news_cover_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news_cover
    ADD CONSTRAINT "FK_news_cover_1" FOREIGN KEY ("ID_COVERSTORY") REFERENCES public.cover_story("ID_COVERSTORY") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: news_cover FK_news_cover_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news_cover
    ADD CONSTRAINT "FK_news_cover_2" FOREIGN KEY ("ID_NEWS") REFERENCES public.news("ID_NEWS") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: likes FK_news_likes; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT "FK_news_likes" FOREIGN KEY ("ID_NEWS") REFERENCES public.news("ID_NEWS") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comments FK_user_comment; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT "FK_user_comment" FOREIGN KEY ("EMAIL") REFERENCES public."user"("EMAIL") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: news FK_user_editor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT "FK_user_editor" FOREIGN KEY ("USER_EDITOR") REFERENCES public.backend_user("USERNAME") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: likes FK_user_likes; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT "FK_user_likes" FOREIGN KEY ("EMAIL") REFERENCES public."user"("EMAIL") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: news FK_user_verificator; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT "FK_user_verificator" FOREIGN KEY ("USER_VERIFICATOR") REFERENCES public.backend_user("USERNAME") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

